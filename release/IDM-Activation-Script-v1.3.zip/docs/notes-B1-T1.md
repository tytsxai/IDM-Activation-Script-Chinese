# Notes - B1-T1

- Centralized argument parsing into :parse_args so unattended flags and elevation parsing stay consistent with v1.2 while living in one place.
- Consolidated relaunch checks into :detect_relaunch_flags / :relaunch_sysnative / :relaunch_sysarm with an explicit _relaunch guard; launch behavior is unchanged.
- Added console helpers :force_codepage and :reset_console plus error-line hooks :eline/:nceline to standardize future logging/silent wiring without altering current output.
- Extracted CLSID backup steps into :backup_clsid reused by activate/reset flows; backup file names and prompts match the prior behavior.
- No intentional changes to menu options, return codes, or activation/reset/freeze side effects; QuickEdit and code page handling remain automatic.
