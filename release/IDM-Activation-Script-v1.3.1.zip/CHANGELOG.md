# 更新日志（CHANGELOG）

本文件记录 IDM 激活脚本中文版的全部对外变更。版本号遵循 [Semantic Versioning](https://semver.org/lang/zh-CN/) 风格：`主版本.次版本.修订号`。

- 格式：每个版本包含 `新增 / 改动 / 修复 / 文档 / 兼容性` 标签（按需出现）。
- 日期使用本地时区（Asia/Shanghai）。
- 最新版本置顶；已冻结版本不再回溯改动。

---

## v1.3.1 — 2026-04-21

### 新增
- `重置激活.cmd`：一键调用 `IAS.cmd /res`，面向需要清理激活/试用状态的用户。
- `普通激活.cmd`：一键调用 `IAS.cmd /act`，与 `快速激活.cmd`（冻结）形成完整入口三件套。
- `.github/ISSUE_TEMPLATE/bug_report.yml`：结构化 Bug 反馈模板，强制带 Windows 版本、IDM 版本、`测试脚本.cmd` 退出码，降低排查成本。
- `.github/ISSUE_TEMPLATE/help.yml`：使用帮助/新手求助模板，降低"不是 bug 但不会用"场景的反馈门槛。
- `.github/ISSUE_TEMPLATE/config.yml`：关闭空白 Issue，引导用户先查 FAQ 与 CHANGELOG。
- `CHANGELOG.md`：将更新日志从 README / release-notes 抽离为唯一来源。
- README 新增"快速下载"区块，指向 GitHub Releases 页面和仓库直链；Badges 补齐平台徽章锚点。
- README 新增"第一次运行前必看"小节，预警 UAC / SmartScreen / 杀软误报等首次运行弹窗。

### 改动
- `测试脚本.cmd`：脚本结束时会明确打印"**第一项未通过的检查**"与建议查阅的 README 章节锚点，退出码语义保持不变，自动化脚本无感知升级。
- `快速激活.cmd`：重写 PowerShell 提权调用，使用 `-FilePath` 严格引号转义，修复路径含单引号或特殊字符时自动提权失败的问题。
- `使用说明.txt`：精简为"三步极简指南 + FAQ 指针"；"建议管理员身份"改为明确的**必读**提示，并补充首次运行弹窗清单。
- `README.md`：
  - 常见问题区新增 Win11 24H2、Defender 云保护拦截、WDAC/AppLocker 策略、IDM 6.42+ 兼容性四条；
  - "版本与维护"段落同步到 v1.3.1；
  - 文件说明表加入三个一键入口；
  - 系统要求表格去掉让小白困惑的"代码页 936"行（脚本已自动设置），改为明确标注"无需手动设置"；
  - "方法二：命令行"折叠到 `<details>` 里，让新手视线聚焦在"方法一：图形界面"上。
- `IAS.cmd`：在脚本头部新增"代码导航"注释块，列出参数解析、环境检测、激活/冻结/重置等主要代码段的大致行号区间，方便后续维护。

### 修复
- `快速激活.cmd` 在 `%~f0` 路径含单引号时 PowerShell `Start-Process` 报语法错误的问题。

### 文档
- `SECURITY.md` 全文中文化，涵盖私下上报渠道、信息要点、处理流程。
- 发布包 `release/IDM-Activation-Script-v1.3.1.zip` 重新打包，内含最新文档。

### CI
- `.github/workflows/ci.yml` 增加一步 `IAS.cmd /?` 冒烟探测：在 `windows-latest` 上验证脚本能在 5 秒内正常返回帮助文本，防止语法级回归进入主分支。

---

## v1.3 — 2025-12-09

### 新增
- `IAS.cmd` 支持 `/silent` 与 `/log=<路径>` 参数，可在无人值守场景抑制菜单交互并输出运行日志。
- `快速激活.cmd` 透传同样参数。
- `测试脚本.cmd` 扩展到 10 项检查，退出码按位汇总便于自动化解析。

### CI
- 新增 GitHub Actions（Windows runner）运行 `tools/validate.ps1`，强制 `.cmd`/`.txt` 保持 GBK 编码与 CRLF 行尾，并探测 `cmd.exe` 语法可用性。

### 文档
- 补充执行流程说明与 v1.3 冒烟计划草稿。

---

## v1.2 — 2024-10-05

### 新增
- `快速激活.cmd`（冻结模式快捷方式）、`测试脚本.cmd`（环境检测）、`使用说明.txt`（快速上手指南）。
- `测试脚本.cmd` 补充 Null 服务、PowerShell 语言模式与 TCP 端口检测，失败时返回非零退出码。

### 改动
- 脚本启动及关键交互中强制 `chcp 936`，并在执行 `cls` 后恢复代码页，保证 CMD 内中文显示正常。
- 主菜单与提示信息中文化，保留冻结/普通激活与重置三种模式。
- 保留自动注册表备份、网络检测与 CLSID 锁定等核心功能。

### 修复
- `快速激活.cmd` 在缺少 PowerShell 时提示手动提权，并向上传递 IAS 的返回码。
- 辅助批处理与文本全部统一为 GBK 编码，确保在中文 CMD 下无乱码。

---

## 更早版本

更早版本的改动散落在提交历史中，不再单独追溯。可通过 `git log --oneline` 查看完整时间线。
